# Technical Specification: RAYD Scientific Calculator Engine for Android

## 1. System Architecture

The application follows a 4-layer decoupled architecture to emulate a dedicated scientific-calculator execution pipeline:

- Layer 1 (UI/View): Jetpack Compose custom Canvas drawing math layouts.
- Layer 2 (Tokenizer/Buffer): Converts keypress matrix positions to structural byte-tokens.
- Layer 3 (State Mode Controller): Directs tokens based on active modes (COMP, CMPLX, MATRIX, EQN).
- Layer 4 (Math Engine): BCD-style arbitrary precision execution using `BigDecimal`.

## 2. Tokenizer Mappings (Hex Array Constants)

Instead of processing raw strings, keys map directly to specific operation tokens:

- Add / Subtract / Multiply / Divide: `[0x01, 0x02, 0x03, 0x04]`
- Trigonometric Open: `SIN(` -> `0x1A`, `COS(` -> `0x1B`, `TAN(` -> `0x1C`
- Formatting Blocks: `FRACTION_OPEN` -> `0x3A`, `FRACTION_DIVIDER` -> `0x3B`, `FRACTION_CLOSE` -> `0x3C`

## 3. Mathematical Execution Constraints

- Do not use native Java/Kotlin `Double` or `Float` primitives for evaluation logic due to binary rounding issues.
- All numbers must pass through `java.math.BigDecimal` with 15 digits of internal mantissa precision.
- Implement the Shunting-Yard parser modified to treat mathematical functions with explicit operational hierarchy overriding baseline operators.
- Transcendental functions (`sin`, `cos`, `tan`) evaluate via an absolute approximation algorithm loop mapping degrees to radians smoothly.

## 4. UI Rendering

- The screen view is divided into a dedicated top status line with indicators (`D`, `R`, `G`, `M`, `S`) and a dynamic 96x31 grid layout view.
- Fractional expressions dynamically calculate nested boundary height and lower the typography scale when sub-fraction tokens are injected.


## Expanded scientific keypad

The app now supports sqrt, square, power, inverse, log, ln, abs, factorial, percent, pi, e, fraction templates, trigonometry, Ans memory, DEL/AC, and standard arithmetic. All executable keys are represented as structural byte tokens before parsing.


## FIXED5 Expanded Scientific Keypad

Added visible scalar scientific keys and engine support for inverse trig, hyperbolic functions, cube/cube-root/nth-root, nPr/nCr, powers, constants, random unit value, memory keys, and fraction/decimal result formatting. Advanced multi-argument symbolic templates and non-COMP modes remain deliberately blocked rather than producing fake results.
