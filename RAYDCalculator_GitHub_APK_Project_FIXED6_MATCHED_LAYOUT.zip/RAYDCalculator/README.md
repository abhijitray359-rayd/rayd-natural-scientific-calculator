# RAYD Scientific Calculator Android APK Project

This repository is a complete Kotlin + Jetpack Compose Android project that can be uploaded directly to GitHub and built into a debug APK using GitHub Actions.

## What is included

- `app/src/main/java/com/rayd/calculator/RaydBuffer.kt`  
  Stateful byte-token buffer with block cursor movement and opcode tokens for digits, operators, functions, constants, postfix keys, and fractions.

- `app/src/main/java/com/rayd/calculator/RaydMathEngine.kt`  
  Shunting-Yard parser, postfix evaluator, `BigDecimal` arithmetic, trigonometric approximation loops, inverse trig, hyperbolic functions, roots, powers, nPr/nCr, inverse, factorial, percentage, absolute value, natural log, base-10 log, constants, memory recall/store/add, random number, and fraction/decimal display.

- `app/src/main/java/com/rayd/calculator/RaydModeController.kt`  
  Mode-routing boundary for COMP, CMPLX, MATRIX, and EQN.

- `app/src/main/java/com/rayd/calculator/RaydDisplay.kt`  
  Jetpack Compose UI with a green LCD-style area, dark operation row, scrollable full scientific keypad grid, memory keys, shifted labels, and scalar feature keys.

- `.github/workflows/build-apk.yml`  
  GitHub Actions workflow that runs unit tests and uploads the generated debug APK.

## Scientific keys included

`CALC`, `a/b`, `√(`, `∛(`, `x²`, `x³`, `xʸ`, `y√x`, `x⁻¹`, `10^(`, `e^(`, `log(`, `ln(`, `abs(`, `!`, `%`, `nPr`, `nCr`, `π`, `e`, `Ran#`, `sin(`, `cos(`, `tan(`, `sin⁻¹(`, `cos⁻¹(`, `tan⁻¹(`, `sinh(`, `cosh(`, `tanh(`, parentheses, `Ans`, `RCL`, `STO`, `M+`, `S⇔D`, `ENG`, `DEL`, `AC`, `+`, `−`, `×`, `÷`, decimal point, and equals.

Planned keys are visible for the hardware-style layout but intentionally blocked in this scalar release: numeric integral template, derivative template, summation template, DMS display conversion, CONST catalog, CONV catalog, and non-COMP engines such as complex/matrix/vector/stat/equation modes.

## Build APK in GitHub

1. Create a new GitHub repository, for example `rayd-calculator-android`.
2. Upload all files from this project zip.
3. Go to the **Actions** tab.
4. Run **Build Android APK** manually, or push to `main`.
5. Download the `rayd-debug-apk` artifact from the completed workflow.

The debug APK will be generated at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Local build

This project intentionally uses the GitHub Action's Gradle installation instead of committing a Gradle wrapper JAR.

```bash
gradle :app:testDebugUnitTest
gradle :app:assembleDebug
```

## Notes

The MVP fully implements scalar COMP mode. CMPLX, MATRIX, and EQN are routed through the mode controller and blocked with a clear message until those engines are added.


## Verification notes

FIXED5 adds the expanded scientific keypad, scalar implementations for inverse trig, hyperbolic functions, cube/cube-root/nth-root, nPr/nCr, 10^x/e^x, random number, memory keys, and extra unit tests.
