# The app currently has no reflection-heavy libraries.
# Keep this file so release builds can enable minification later without restructuring.
