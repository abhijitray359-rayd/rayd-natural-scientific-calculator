package com.rayd.calculator

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.math.BigDecimal
import java.math.BigInteger

@Composable
fun RaydDisplay(
    modifier: Modifier = Modifier,
    buffer: RaydBuffer = remember { RaydBuffer() },
    engine: RaydMathEngine = remember { RaydMathEngine() },
    modeController: RaydModeController = remember { RaydModeController(buffer) }
) {
    var resultText by rememberSaveable { mutableStateOf("0") }
    var errorText by rememberSaveable { mutableStateOf<String?>(null) }
    var shiftEnabled by rememberSaveable { mutableStateOf(false) }
    var alphaEnabled by rememberSaveable { mutableStateOf(false) }
    var hypEnabled by rememberSaveable { mutableStateOf(false) }
    var angleMode by rememberSaveable { mutableStateOf(RaydAngleMode.DEGREES) }
    var lastAnswer by remember { mutableStateOf(BigDecimal.ZERO) }
    var memoryValue by remember { mutableStateOf(BigDecimal.ZERO) }


    fun markInputChanged(accepted: Boolean) {
        errorText = if (accepted) {
            null
        } else {
            "Advanced key/mode is not available in scalar mode"
        }
    }

    fun evaluateNow() {
        if (modeController.mode != RaydCalculatorMode.COMP) {
            errorText = "Advanced key/mode is not available in scalar mode"
            return
        }

        when (
            val result = engine.evaluate(
                tokens = buffer.snapshot(),
                ans = lastAnswer,
                angleMode = angleMode
            )
        ) {
            is RaydEvaluationResult.Success -> {
                lastAnswer = result.value
                resultText = result.display
                errorText = null
            }

            is RaydEvaluationResult.Error -> {
                errorText = result.message
            }
        }
    }


    fun memoryAdd() {
        memoryValue = memoryValue.add(lastAnswer)
        errorText = null
    }

    fun memoryStore() {
        memoryValue = lastAnswer
        errorText = null
    }

    fun memoryRecall() {
        val accepted = modeController.handle(RaydInputIntent.NumberLiteral(engine.formatResult(memoryValue)))
        markInputChanged(accepted)
    }

    fun toggleFractionDecimal() {
        resultText = resultText.toFractionStringOrNull() ?: resultText
        errorText = null
    }

    fun clearAll() {
        buffer.clear()
        resultText = "0"
        errorText = null
        shiftEnabled = false
        alphaEnabled = false
        hypEnabled = false
        modeController.resetMode()
    }

    MaterialTheme {
        Surface(
            modifier = modifier.fillMaxSize(),
            color = Color(0xFF202329)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                NaturalMathLcd(
                    buffer = buffer,
                    resultText = resultText,
                    errorText = errorText,
                    angleMode = angleMode,
                    calculatorMode = modeController.mode,
                    shiftEnabled = shiftEnabled,
                    alphaEnabled = alphaEnabled,
                    memoryActive = memoryValue.compareTo(BigDecimal.ZERO) != 0,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(156.dp)
                )

                OperationalControlRow(
                    shiftEnabled = shiftEnabled,
                    alphaEnabled = alphaEnabled,
                    angleMode = angleMode,
                    calculatorMode = modeController.mode,
                    onShift = { shiftEnabled = !shiftEnabled },
                    onAlpha = { alphaEnabled = !alphaEnabled },
                    onLeft = { buffer.moveLeft() },
                    onRight = { buffer.moveRight() },
                    onMode = {
                        buffer.clear()
                        modeController.cycleMode()
                        errorText = null
                    },
                    onAngleMode = { angleMode = angleMode.next() },
                    onOn = { clearAll() },
                    modifier = Modifier.fillMaxWidth()
                )

                KeypadGrid(
                    modeController = modeController,
                    shiftEnabled = shiftEnabled,
                    alphaEnabled = alphaEnabled,
                    hypEnabled = hypEnabled,
                    onInput = ::markInputChanged,
                    onDelete = {
                        buffer.deleteBeforeCursor()
                        markInputChanged(true)
                    },
                    onAllClear = ::clearAll,
                    onEquals = ::evaluateNow,
                    onMemoryAdd = ::memoryAdd,
                    onMemoryStore = ::memoryStore,
                    onMemoryRecall = ::memoryRecall,
                    onToggleFractionDecimal = ::toggleFractionDecimal,
                    onAngleMode = { angleMode = angleMode.next() },
                    onHyp = {
                        hypEnabled = !hypEnabled
                        errorText = null
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun NaturalMathLcd(
    buffer: RaydBuffer,
    resultText: String,
    errorText: String?,
    angleMode: RaydAngleMode,
    calculatorMode: RaydCalculatorMode,
    shiftEnabled: Boolean,
    alphaEnabled: Boolean,
    memoryActive: Boolean,
    modifier: Modifier = Modifier
) {
    val tokens = buffer.tokens.toList()
    val cursorIndex = buffer.cursorIndex
    val fractionDepth = buffer.maxFractionDepth()

    Canvas(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFFBFD9C8))
    ) {
        val gridWidth = size.width / 96f
        val gridHeight = size.height / 31f
        val nativeCanvas = drawContext.canvas.nativeCanvas

        drawRoundRect(
            color = Color(0xFFBFD9C8),
            cornerRadius = CornerRadius(18f, 18f)
        )

        drawRoundRect(
            color = Color(0xFF5A7D65),
            style = Stroke(width = gridWidth.coerceAtLeast(2f)),
            cornerRadius = CornerRadius(18f, 18f)
        )

        drawRect(
            color = Color(0x335A7D65),
            topLeft = Offset(0f, gridHeight * 5f),
            size = Size(size.width, gridHeight * 0.35f)
        )

        for (column in 0..96 step 12) {
            drawLine(
                color = Color(0x145A7D65),
                start = Offset(column * gridWidth, gridHeight * 5f),
                end = Offset(column * gridWidth, size.height),
                strokeWidth = 1f
            )
        }

        for (row in 5..31 step 6) {
            drawLine(
                color = Color(0x145A7D65),
                start = Offset(0f, row * gridHeight),
                end = Offset(size.width, row * gridHeight),
                strokeWidth = 1f
            )
        }

        val statusPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textSize = gridHeight * 3.1f
            textAlign = Paint.Align.LEFT
        }

        val mutedStatusColor = Color(0x66536E58).toArgb()
        val activeStatusColor = Color(0xFF153B26).toArgb()

        val indicators = listOf(
            "D" to (angleMode == RaydAngleMode.DEGREES),
            "R" to (angleMode == RaydAngleMode.RADIANS),
            "G" to (angleMode == RaydAngleMode.GRADS),
            "M" to memoryActive,
            "S" to shiftEnabled
        )

        var statusX = gridWidth * 3f
        for ((label, active) in indicators) {
            statusPaint.color = if (active) activeStatusColor else mutedStatusColor
            nativeCanvas.drawText(label, statusX, gridHeight * 3.6f, statusPaint)
            statusX += gridWidth * 7f
        }

        statusPaint.color = activeStatusColor
        nativeCanvas.drawText(calculatorMode.statusLabel(), statusX, gridHeight * 3.6f, statusPaint)
        statusX += gridWidth * 16f

        if (alphaEnabled) {
            statusPaint.color = activeStatusColor
            nativeCanvas.drawText("A", statusX, gridHeight * 3.6f, statusPaint)
        }

        val expressionFontSize = when {
            fractionDepth >= 2 -> gridHeight * 4.35f
            fractionDepth == 1 -> gridHeight * 5.1f
            else -> gridHeight * 5.9f
        }

        val expressionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color(0xFF163624).toArgb()
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
            textSize = expressionFontSize
            textAlign = Paint.Align.LEFT
        }

        var x = gridWidth * 3f
        var y = gridHeight * 14.4f
        val minX = gridWidth * 3f
        val maxX = size.width - gridWidth * 3f

        fun drawCursor(cursorX: Float, baselineY: Float) {
            drawLine(
                color = Color(0xFF153B26),
                start = Offset(cursorX, baselineY - expressionFontSize),
                end = Offset(cursorX, baselineY + gridHeight * 0.9f),
                strokeWidth = maxOf(1.5f, gridWidth * 0.45f)
            )
        }

        for ((index, token) in tokens.withIndex()) {
            if (index == cursorIndex) {
                drawCursor(x, y)
            }

            val textWidth = expressionPaint.measureText(token.display)
            if (x + textWidth > maxX && x > minX) {
                x = minX
                y += expressionFontSize * 1.35f
            }

            if (token.kind == RaydTokenKind.FRACTION_DIVIDER) {
                val lineY = y - expressionFontSize * 0.38f
                val lineWidth = gridWidth * 5.5f

                drawLine(
                    color = Color(0xFF163624),
                    start = Offset(x, lineY),
                    end = Offset(x + lineWidth, lineY),
                    strokeWidth = maxOf(1.2f, gridHeight * 0.18f)
                )

                x += lineWidth + gridWidth * 0.8f
            } else {
                nativeCanvas.drawText(token.display, x, y, expressionPaint)
                x += textWidth
            }
        }

        if (cursorIndex == tokens.size) {
            drawCursor(x, y)
        }

        val resultPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (errorText == null) {
                Color(0xFF153B26).toArgb()
            } else {
                Color(0xFF7A1F1F).toArgb()
            }
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textSize = gridHeight * 4.85f
            textAlign = Paint.Align.RIGHT
        }

        val rawResult = errorText ?: resultText
        val displayResult = if (rawResult.length > 28) {
            "…" + rawResult.takeLast(27)
        } else {
            rawResult
        }

        nativeCanvas.drawText(
            displayResult,
            size.width - gridWidth * 3f,
            size.height - gridHeight * 2.4f,
            resultPaint
        )
    }
}


@Composable
private fun OperationalControlRow(
    shiftEnabled: Boolean,
    alphaEnabled: Boolean,
    angleMode: RaydAngleMode,
    calculatorMode: RaydCalculatorMode,
    onShift: () -> Unit,
    onAlpha: () -> Unit,
    onLeft: () -> Unit,
    onRight: () -> Unit,
    onMode: () -> Unit,
    onAngleMode: () -> Unit,
    onOn: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = Color(0xFF2C3038),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
            horizontalArrangement = Arrangement.spacedBy(7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ControlPill(
                label = "SHIFT",
                active = shiftEnabled,
                onClick = onShift,
                modifier = Modifier.weight(1.05f)
            )

            ControlPill(
                label = "ALPHA",
                active = alphaEnabled,
                onClick = onAlpha,
                modifier = Modifier.weight(1.05f)
            )

            DPadControl(
                onLeft = onLeft,
                onRight = onRight,
                onUp = {},
                onDown = {},
                modifier = Modifier.weight(2.1f)
            )

            ControlPill(
                label = "MODE\nSETUP",
                active = calculatorMode != RaydCalculatorMode.COMP,
                onClick = onMode,
                modifier = Modifier.weight(1.15f)
            )

            ControlPill(
                label = "DRG ${angleMode.statusLabel()}",
                active = false,
                onClick = onAngleMode,
                modifier = Modifier.weight(1.05f)
            )

            ControlPill(
                label = "ON",
                active = false,
                onClick = onOn,
                modifier = Modifier.weight(0.82f)
            )
        }
    }
}

@Composable
private fun DPadControl(
    onLeft: () -> Unit,
    onRight: () -> Unit,
    onUp: () -> Unit,
    onDown: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.height(74.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        MiniPadButton("▲", onUp, Modifier.weight(1f).fillMaxWidth(0.46f))

        Row(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            MiniPadButton("◀", onLeft, Modifier.weight(1f))
            MiniPadButton("OK", {}, Modifier.weight(1f))
            MiniPadButton("▶", onRight, Modifier.weight(1f))
        }

        MiniPadButton("▼", onDown, Modifier.weight(1f).fillMaxWidth(0.46f))
    }
}

@Composable
private fun MiniPadButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(11.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFF4A505B),
            contentColor = Color.White
        ),
        contentPadding = PaddingValues(0.dp)
    ) {
        Text(
            text = label,
            fontSize = 8.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
    }
}

@Composable
private fun ControlPill(
    label: String,
    active: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        modifier = modifier.height(48.dp),
        shape = RoundedCornerShape(22.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (active) Color(0xFF7E8E35) else Color(0xFF4A505B),
            contentColor = Color.White
        ),
        contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp)
    ) {
        Text(
            text = label,
            fontSize = 8.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            maxLines = 2
        )
    }
}

@Composable
private fun KeypadGrid(
    modeController: RaydModeController,
    shiftEnabled: Boolean,
    alphaEnabled: Boolean,
    hypEnabled: Boolean,
    onInput: (Boolean) -> Unit,
    onDelete: () -> Unit,
    onAllClear: () -> Unit,
    onEquals: () -> Unit,
    onMemoryAdd: () -> Unit,
    onMemoryStore: () -> Unit,
    onMemoryRecall: () -> Unit,
    onToggleFractionDecimal: () -> Unit,
    onAngleMode: () -> Unit,
    onHyp: () -> Unit,
    modifier: Modifier = Modifier
) {
    fun route(intent: RaydInputIntent) {
        onInput(modeController.handle(intent))
    }

    fun unavailable() {
        onInput(false)
    }

    fun trig(normal: Int, inverse: Int, hyperbolic: Int) {
        when {
            shiftEnabled -> route(RaydInputIntent.FunctionOpen(inverse))
            hypEnabled -> route(RaydInputIntent.FunctionOpen(hyperbolic))
            else -> route(RaydInputIntent.FunctionOpen(normal))
        }
    }

    fun expKey() {
        when {
            shiftEnabled -> route(RaydInputIntent.Constant(RaydOpcode.CONST_PI))
            alphaEnabled -> route(RaydInputIntent.Constant(RaydOpcode.CONST_E))
            else -> {
                route(RaydInputIntent.Operator(RaydOpcode.MULTIPLY))
                route(RaydInputIntent.FunctionOpen(RaydOpcode.POW10_OPEN))
            }
        }
    }

    val topFunctionRows = listOf(
        listOf(
            RaydKeySpec("CALC", "SOLVE", KeyKind.Function) { onEquals() },
            RaydKeySpec("∫dx", "d/dx", KeyKind.Function) { unavailable() },
            RaydKeySpec.blank(),
            RaydKeySpec.blank(),
            RaydKeySpec("x⁻¹", "x!", KeyKind.Function) {
                if (shiftEnabled) {
                    route(RaydInputIntent.PostfixOperator(RaydOpcode.FACTORIAL))
                } else {
                    route(RaydInputIntent.PostfixOperator(RaydOpcode.INVERSE))
                }
            },
            RaydKeySpec("log□", "Σ", KeyKind.Function) {
                if (shiftEnabled) unavailable() else route(RaydInputIntent.FunctionOpen(RaydOpcode.LOG_OPEN))
            }
        ),
        listOf(
            RaydKeySpec("a/b", "▭/▭", KeyKind.Function) { route(RaydInputIntent.FractionTemplate) },
            RaydKeySpec("√", "∛", KeyKind.Function) {
                if (shiftEnabled) {
                    route(RaydInputIntent.FunctionOpen(RaydOpcode.CBRT_OPEN))
                } else {
                    route(RaydInputIntent.FunctionOpen(RaydOpcode.SQRT_OPEN))
                }
            },
            RaydKeySpec("x²", "x³", KeyKind.Function) {
                if (shiftEnabled) {
                    route(RaydInputIntent.PostfixOperator(RaydOpcode.CUBE))
                } else {
                    route(RaydInputIntent.PostfixOperator(RaydOpcode.SQUARE))
                }
            },
            RaydKeySpec("x^□", "y√x", KeyKind.Operator) {
                if (shiftEnabled) {
                    route(RaydInputIntent.Operator(RaydOpcode.NTH_ROOT))
                } else {
                    route(RaydInputIntent.Operator(RaydOpcode.POWER))
                }
            },
            RaydKeySpec("log", "10^x", KeyKind.Function) {
                if (shiftEnabled) {
                    route(RaydInputIntent.FunctionOpen(RaydOpcode.POW10_OPEN))
                } else {
                    route(RaydInputIntent.FunctionOpen(RaydOpcode.LOG_OPEN))
                }
            },
            RaydKeySpec("ln", "e^x", KeyKind.Function) {
                if (shiftEnabled) {
                    route(RaydInputIntent.FunctionOpen(RaydOpcode.EXP_OPEN))
                } else {
                    route(RaydInputIntent.FunctionOpen(RaydOpcode.LN_OPEN))
                }
            }
        ),
        listOf(
            RaydKeySpec("(-)", "A", KeyKind.Operator) { route(RaydInputIntent.Operator(RaydOpcode.SUBTRACT)) },
            RaydKeySpec("°′″", "B", KeyKind.Function) { unavailable() },
            RaydKeySpec("hyp", "Abs", KeyKind.Function) {
                if (shiftEnabled) {
                    route(RaydInputIntent.FunctionOpen(RaydOpcode.ABS_OPEN))
                } else {
                    onHyp()
                }
            },
            RaydKeySpec("sin", if (hypEnabled) "sinh" else "sin⁻¹", KeyKind.Function) {
                trig(RaydOpcode.SIN_OPEN, RaydOpcode.ASIN_OPEN, RaydOpcode.SINH_OPEN)
            },
            RaydKeySpec("cos", if (hypEnabled) "cosh" else "cos⁻¹", KeyKind.Function) {
                trig(RaydOpcode.COS_OPEN, RaydOpcode.ACOS_OPEN, RaydOpcode.COSH_OPEN)
            },
            RaydKeySpec("tan", if (hypEnabled) "tanh" else "tan⁻¹", KeyKind.Function) {
                trig(RaydOpcode.TAN_OPEN, RaydOpcode.ATAN_OPEN, RaydOpcode.TANH_OPEN)
            }
        ),
        listOf(
            RaydKeySpec("RCL", "STO", KeyKind.Function) {
                if (shiftEnabled) onMemoryStore() else onMemoryRecall()
            },
            RaydKeySpec("ENG", "i", KeyKind.Function) {
                route(RaydInputIntent.Operator(RaydOpcode.MULTIPLY))
                route(RaydInputIntent.FunctionOpen(RaydOpcode.POW10_OPEN))
            },
            RaydKeySpec("(", "%", KeyKind.Function) {
                if (shiftEnabled) {
                    route(RaydInputIntent.PostfixOperator(RaydOpcode.PERCENT))
                } else {
                    route(RaydInputIntent.LeftParen)
                }
            },
            RaydKeySpec(")", ",", KeyKind.Function) {
                route(RaydInputIntent.RightParen)
            },
            RaydKeySpec("S⇔D", "a b/c", KeyKind.Function) { onToggleFractionDecimal() },
            RaydKeySpec("M+", "M−", KeyKind.Function) { onMemoryAdd() }
        )
    )

    val numberRows = listOf(
        listOf(
            RaydKeySpec("7", "CONST", KeyKind.Number) {
                if (shiftEnabled) unavailable() else route(RaydInputIntent.Digit(7))
            },
            RaydKeySpec("8", "CONV", KeyKind.Number) {
                if (shiftEnabled) unavailable() else route(RaydInputIntent.Digit(8))
            },
            RaydKeySpec("9", "CLR", KeyKind.Number) {
                if (shiftEnabled) unavailable() else route(RaydInputIntent.Digit(9))
            },
            RaydKeySpec("DEL", "INS", KeyKind.Control) { onDelete() },
            RaydKeySpec("AC", "OFF", KeyKind.Control) { onAllClear() }
        ),
        listOf(
            RaydKeySpec("4", "MATRIX", KeyKind.Number) {
                if (shiftEnabled) unavailable() else route(RaydInputIntent.Digit(4))
            },
            RaydKeySpec("5", "VECTOR", KeyKind.Number) {
                if (shiftEnabled) unavailable() else route(RaydInputIntent.Digit(5))
            },
            RaydKeySpec("6", "", KeyKind.Number) { route(RaydInputIntent.Digit(6)) },
            RaydKeySpec("×", "nPr", KeyKind.Operator) {
                if (shiftEnabled) {
                    route(RaydInputIntent.Operator(RaydOpcode.NPR))
                } else {
                    route(RaydInputIntent.Operator(RaydOpcode.MULTIPLY))
                }
            },
            RaydKeySpec("÷", "nCr", KeyKind.Operator) {
                if (shiftEnabled) {
                    route(RaydInputIntent.Operator(RaydOpcode.NCR))
                } else {
                    route(RaydInputIntent.Operator(RaydOpcode.DIVIDE))
                }
            }
        ),
        listOf(
            RaydKeySpec("1", "STAT", KeyKind.Number) {
                if (shiftEnabled) unavailable() else route(RaydInputIntent.Digit(1))
            },
            RaydKeySpec("2", "CMPLX", KeyKind.Number) {
                if (shiftEnabled) unavailable() else route(RaydInputIntent.Digit(2))
            },
            RaydKeySpec("3", "BASE-N", KeyKind.Number) {
                if (shiftEnabled) unavailable() else route(RaydInputIntent.Digit(3))
            },
            RaydKeySpec("+", "Pol", KeyKind.Operator) { route(RaydInputIntent.Operator(RaydOpcode.ADD)) },
            RaydKeySpec("−", "Rec", KeyKind.Operator) { route(RaydInputIntent.Operator(RaydOpcode.SUBTRACT)) }
        ),
        listOf(
            RaydKeySpec("0", "Rnd", KeyKind.Number) { route(RaydInputIntent.Digit(0)) },
            RaydKeySpec(".", "Ran#", KeyKind.Number) {
                if (shiftEnabled) {
                    route(RaydInputIntent.Constant(RaydOpcode.CONST_RANDOM))
                } else {
                    route(RaydInputIntent.DecimalPoint)
                }
            },
            RaydKeySpec("×10^x", "π / e", KeyKind.Function) { expKey() },
            RaydKeySpec("Ans", "DRG▶", KeyKind.Function) {
                if (shiftEnabled) onAngleMode() else route(RaydInputIntent.Answer)
            },
            RaydKeySpec("=", null, KeyKind.Equals) { onEquals() }
        )
    )

    Surface(
        modifier = modifier,
        color = Color(0xFF22262C),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                for (row in topFunctionRows) {
                    KeyRow(row)
                }
            }

            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFFC8CCD2),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(7.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    for (row in numberRows) {
                        KeyRow(row)
                    }
                }
            }
        }
    }
}

@Composable
private fun KeyRow(
    row: List<RaydKeySpec>,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        for (key in row) {
            RaydKey(
                spec = key,
                modifier = Modifier
                    .weight(1f)
                    .aspectRatio(1.16f)
            )
        }
    }
}

@Composable
private fun RaydKey(
    spec: RaydKeySpec,
    modifier: Modifier = Modifier
) {
    if (spec.kind == KeyKind.Blank) {
        Surface(
            modifier = modifier,
            color = Color.Transparent,
            shape = RoundedCornerShape(10.dp)
        ) {}
        return
    }

    val containerColor = when (spec.kind) {
        KeyKind.Number -> Color(0xFFE7E9ED)
        KeyKind.Function -> Color(0xFF303641)
        KeyKind.Operator -> Color(0xFFBFC5CE)
        KeyKind.Control -> Color(0xFF8AC547)
        KeyKind.Equals -> Color(0xFFBAC2CC)
        KeyKind.Blank -> Color.Transparent
    }

    val contentColor = when (spec.kind) {
        KeyKind.Number -> Color(0xFF22262C)
        KeyKind.Function -> Color.White
        KeyKind.Operator -> Color(0xFF1F252D)
        KeyKind.Control -> Color.White
        KeyKind.Equals -> Color(0xFF1F252D)
        KeyKind.Blank -> Color.Transparent
    }

    Button(
        onClick = spec.onPress,
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = contentColor
        ),
        contentPadding = PaddingValues(0.dp)
    ) {
        BoxWithConstraints(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            val keyMaxWidth = maxWidth

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                if (!spec.hint.isNullOrBlank()) {
                    Text(
                        text = spec.hint,
                        fontSize = 7.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        textAlign = TextAlign.Center
                    )
                }

                Text(
                    text = spec.label,
                    fontSize = if (keyMaxWidth < 48.dp) 13.sp else 16.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

private data class RaydKeySpec(
    val label: String,
    val hint: String?,
    val kind: KeyKind,
    val onPress: () -> Unit
) {
    companion object {
        fun blank(): RaydKeySpec = RaydKeySpec(
            label = "",
            hint = null,
            kind = KeyKind.Blank,
            onPress = {}
        )
    }
}

private enum class KeyKind {
    Number,
    Function,
    Operator,
    Control,
    Equals,
    Blank
}


private fun String.toFractionStringOrNull(): String? {
    val clean = trim().replace("−", "-")
    if (clean.isEmpty() || clean.contains("/") || clean.any { it.isLetter() }) return null

    val value = try {
        BigDecimal(clean).stripTrailingZeros()
    } catch (exception: NumberFormatException) {
        return null
    }

    if (value.scale() <= 0) {
        return value.toPlainString()
    }

    val numerator = value.unscaledValue()
    val denominator = BigInteger.TEN.pow(value.scale())
    val gcd = numerator.abs().gcd(denominator)
    val reducedNumerator = numerator.divide(gcd)
    val reducedDenominator = denominator.divide(gcd)

    return "$reducedNumerator/$reducedDenominator"
}

private fun RaydAngleMode.next(): RaydAngleMode {
    return when (this) {
        RaydAngleMode.DEGREES -> RaydAngleMode.RADIANS
        RaydAngleMode.RADIANS -> RaydAngleMode.GRADS
        RaydAngleMode.GRADS -> RaydAngleMode.DEGREES
    }
}

private fun RaydAngleMode.statusLabel(): String {
    return when (this) {
        RaydAngleMode.DEGREES -> "D"
        RaydAngleMode.RADIANS -> "R"
        RaydAngleMode.GRADS -> "G"
    }
}
