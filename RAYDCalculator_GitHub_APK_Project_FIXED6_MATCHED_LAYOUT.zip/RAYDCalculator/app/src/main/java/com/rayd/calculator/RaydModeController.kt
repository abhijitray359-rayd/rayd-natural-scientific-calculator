package com.rayd.calculator

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class RaydCalculatorMode {
    COMP,
    CMPLX,
    MATRIX,
    EQN
}

sealed class RaydInputIntent {
    data class Digit(val value: Int) : RaydInputIntent()
    data object DecimalPoint : RaydInputIntent()
    data class Operator(val opcode: Int) : RaydInputIntent()
    data class PostfixOperator(val opcode: Int) : RaydInputIntent()
    data class FunctionOpen(val opcode: Int) : RaydInputIntent()
    data class Constant(val opcode: Int) : RaydInputIntent()
    data object LeftParen : RaydInputIntent()
    data object RightParen : RaydInputIntent()
    data object FractionTemplate : RaydInputIntent()
    data object Answer : RaydInputIntent()
    data class NumberLiteral(val value: String) : RaydInputIntent()
}

class RaydModeController(
    private val buffer: RaydBuffer,
    initialMode: RaydCalculatorMode = RaydCalculatorMode.COMP
) {
    var mode: RaydCalculatorMode by mutableStateOf(initialMode)
        private set

    fun cycleMode() {
        mode = when (mode) {
            RaydCalculatorMode.COMP -> RaydCalculatorMode.CMPLX
            RaydCalculatorMode.CMPLX -> RaydCalculatorMode.MATRIX
            RaydCalculatorMode.MATRIX -> RaydCalculatorMode.EQN
            RaydCalculatorMode.EQN -> RaydCalculatorMode.COMP
        }
    }

    fun resetMode() {
        mode = RaydCalculatorMode.COMP
    }

    fun handle(intent: RaydInputIntent): Boolean {
        /*
         * COMP mode accepts scalar expressions.
         * Other mode names are exposed so the UI resembles a scientific calculator,
         * but their execution models remain intentionally isolated for future releases.
         */
        if (mode != RaydCalculatorMode.COMP) {
            return false
        }

        return when (intent) {
            is RaydInputIntent.Digit -> buffer.insertDigit(intent.value)
            RaydInputIntent.DecimalPoint -> buffer.insertDecimalPoint()
            is RaydInputIntent.Operator -> buffer.insertOperator(intent.opcode)
            is RaydInputIntent.PostfixOperator -> buffer.insertPostfixOperator(intent.opcode)
            is RaydInputIntent.FunctionOpen -> buffer.insertFunctionOpen(intent.opcode)
            is RaydInputIntent.Constant -> buffer.insertConstant(intent.opcode)
            RaydInputIntent.LeftParen -> buffer.insertLeftParen()
            RaydInputIntent.RightParen -> buffer.insertRightParen()
            RaydInputIntent.FractionTemplate -> buffer.insertFractionTemplate()
            RaydInputIntent.Answer -> buffer.insertAnswer()
            is RaydInputIntent.NumberLiteral -> buffer.insertNumberLiteral(intent.value)
        }
    }
}

fun RaydCalculatorMode.statusLabel(): String {
    return when (this) {
        RaydCalculatorMode.COMP -> "COMP"
        RaydCalculatorMode.CMPLX -> "CMPLX"
        RaydCalculatorMode.MATRIX -> "MAT"
        RaydCalculatorMode.EQN -> "EQN"
    }
}
