package com.rayd.calculator

import java.math.BigDecimal
import java.math.BigInteger
import java.math.MathContext
import java.math.RoundingMode
import java.util.ArrayDeque
import kotlin.random.Random

enum class RaydAngleMode {
    DEGREES,
    RADIANS,
    GRADS
}

sealed class RaydEvaluationResult {
    data class Success(
        val value: BigDecimal,
        val display: String,
        val postfix: List<RaydPostfixToken>
    ) : RaydEvaluationResult()

    data class Error(
        val message: String
    ) : RaydEvaluationResult()
}

sealed class RaydPostfixToken {
    data class Number(val value: BigDecimal) : RaydPostfixToken()

    data class Operator(
        val code: Int,
        val symbol: String,
        val arity: Int
    ) : RaydPostfixToken()

    data class Function(
        val code: Int,
        val name: String
    ) : RaydPostfixToken()
}

class RaydMathEngine(
    private val mathContext: MathContext = MathContext(15, RoundingMode.HALF_UP)
) {
    private val workContext = MathContext(28, RoundingMode.HALF_UP)

    private val zero = BigDecimal.ZERO
    private val one = BigDecimal.ONE
    private val two = BigDecimal("2", workContext)
    private val ten = BigDecimal.TEN
    private val hundred = BigDecimal("100", workContext)

    private val pi = BigDecimal("3.14159265358979", workContext)
    private val e = BigDecimal("2.71828182845905", workContext)
    private val lnTen = BigDecimal("2.30258509299405", workContext)

    private val twoPi = pi.multiply(two, workContext)
    private val oneEighty = BigDecimal("180", workContext)
    private val twoHundred = BigDecimal("200", workContext)

    private val seriesEpsilon = BigDecimal("1E-24")
    private val displayZeroEpsilon = BigDecimal("1E-12")
    private val tangentZeroEpsilon = BigDecimal("1E-14")

    fun evaluate(
        tokens: List<RaydToken>,
        ans: BigDecimal = BigDecimal.ZERO,
        angleMode: RaydAngleMode = RaydAngleMode.DEGREES
    ): RaydEvaluationResult {
        return try {
            val postfix = toPostfix(tokens = tokens, ans = ans)
            val value = evaluatePostfix(postfix = postfix, angleMode = angleMode)
            val rounded = snapTiny(value.round(mathContext))

            RaydEvaluationResult.Success(
                value = rounded,
                display = formatResult(rounded),
                postfix = postfix
            )
        } catch (exception: RaydParseException) {
            RaydEvaluationResult.Error(exception.message ?: "Syntax error.")
        } catch (exception: RaydExecutionException) {
            RaydEvaluationResult.Error(exception.message ?: "Math error.")
        } catch (exception: ArithmeticException) {
            RaydEvaluationResult.Error(exception.message ?: "Arithmetic error.")
        } catch (exception: IllegalArgumentException) {
            RaydEvaluationResult.Error(exception.message ?: "Invalid expression.")
        }
    }

    fun toPostfix(
        tokens: List<RaydToken>,
        ans: BigDecimal = BigDecimal.ZERO
    ): List<RaydPostfixToken> {
        if (tokens.isEmpty()) {
            throw RaydParseException("Expression is empty.")
        }

        val output = mutableListOf<RaydPostfixToken>()
        val operatorStack = ArrayDeque<StackEntry>()
        var index = 0
        var expectsValue = true

        while (index < tokens.size) {
            val token = tokens[index]

            if (!expectsValue && beginsValue(token)) {
                pushOperator(
                    incoming = binaryOperatorFor(RaydOpcode.MULTIPLY),
                    stack = operatorStack,
                    output = output
                )
                expectsValue = true
                continue
            }

            when (token.kind) {
                RaydTokenKind.DIGIT,
                RaydTokenKind.DECIMAL_POINT -> {
                    val parsed = parseNumber(tokens, index)
                    output.add(RaydPostfixToken.Number(parsed.value))
                    index = parsed.nextIndex
                    expectsValue = false
                    continue
                }

                RaydTokenKind.ANSWER -> {
                    output.add(RaydPostfixToken.Number(ans.round(workContext)))
                    expectsValue = false
                }

                RaydTokenKind.CONSTANT -> {
                    output.add(
                        RaydPostfixToken.Number(
                            when (token.code) {
                                RaydOpcode.CONST_PI -> pi
                                RaydOpcode.CONST_E -> e
                                RaydOpcode.CONST_RANDOM -> randomUnit()
                                else -> throw RaydParseException("Unknown constant.")
                            }
                        )
                    )
                    expectsValue = false
                }

                RaydTokenKind.OPERATOR -> {
                    val operatorInfo = if (expectsValue) {
                        if (token.code == RaydOpcode.SUBTRACT) {
                            unaryMinusOperator()
                        } else {
                            throw RaydParseException("Missing left operand before '${token.display}'.")
                        }
                    } else {
                        binaryOperatorFor(token.code)
                    }

                    pushOperator(
                        incoming = operatorInfo,
                        stack = operatorStack,
                        output = output
                    )
                    expectsValue = true
                }

                RaydTokenKind.POSTFIX_OPERATOR -> {
                    if (expectsValue) {
                        throw RaydParseException("Missing value before '${token.display}'.")
                    }

                    output.add(postfixOperatorFor(token.code).toPostfixOperator())
                    expectsValue = false
                }

                RaydTokenKind.FUNCTION_OPEN -> {
                    operatorStack.addLast(StackEntry.Function(functionFor(token.code)))
                    operatorStack.addLast(StackEntry.LeftParenthesis)
                    expectsValue = true
                }

                RaydTokenKind.LEFT_PAREN,
                RaydTokenKind.FRACTION_OPEN -> {
                    operatorStack.addLast(StackEntry.LeftParenthesis)
                    expectsValue = true
                }

                RaydTokenKind.RIGHT_PAREN,
                RaydTokenKind.FRACTION_CLOSE -> {
                    if (expectsValue) {
                        throw RaydParseException("Missing value before closing delimiter.")
                    }

                    closeParenthesis(
                        stack = operatorStack,
                        output = output
                    )
                    expectsValue = false
                }

                RaydTokenKind.FRACTION_DIVIDER -> {
                    if (expectsValue) {
                        throw RaydParseException("Missing fraction numerator.")
                    }

                    pushOperator(
                        incoming = binaryOperatorFor(RaydOpcode.DIVIDE),
                        stack = operatorStack,
                        output = output
                    )
                    expectsValue = true
                }
            }

            index += 1
        }

        if (expectsValue) {
            throw RaydParseException("Expression ended after an operator or function opener.")
        }

        while (!operatorStack.isEmpty()) {
            when (val entry = operatorStack.removeLast()) {
                StackEntry.LeftParenthesis -> {
                    throw RaydParseException("Missing closing parenthesis.")
                }

                is StackEntry.Function -> {
                    throw RaydParseException("Function '${entry.info.name}' is missing a closing parenthesis.")
                }

                is StackEntry.Operator -> {
                    output.add(entry.info.toPostfixOperator())
                }
            }
        }

        return output
    }

    fun formatResult(value: BigDecimal): String {
        val snapped = snapTiny(value.round(mathContext))

        if (snapped.compareTo(zero) == 0) {
            return "0"
        }

        val plain = snapped.stripTrailingZeros().toPlainString()
        return if (plain == "-0") "0" else plain
    }

    private fun evaluatePostfix(
        postfix: List<RaydPostfixToken>,
        angleMode: RaydAngleMode
    ): BigDecimal {
        val stack = ArrayDeque<BigDecimal>()

        for (token in postfix) {
            when (token) {
                is RaydPostfixToken.Number -> {
                    stack.addLast(token.value.round(workContext))
                }

                is RaydPostfixToken.Operator -> {
                    when (token.arity) {
                        1 -> {
                            val value = popValue(stack)
                            stack.addLast(applyUnaryOperator(token.code, value))
                        }

                        2 -> {
                            val right = popValue(stack)
                            val left = popValue(stack)
                            stack.addLast(applyBinaryOperator(token.code, left, right))
                        }

                        else -> throw RaydExecutionException("Unsupported operator arity: ${token.arity}")
                    }
                }

                is RaydPostfixToken.Function -> {
                    val value = popValue(stack)
                    stack.addLast(applyFunction(token.code, value, angleMode))
                }
            }
        }

        if (stack.size != 1) {
            throw RaydExecutionException("Expression did not reduce to one result.")
        }

        return stack.removeLast().round(workContext)
    }

    private fun popValue(stack: ArrayDeque<BigDecimal>): BigDecimal {
        if (stack.isEmpty()) {
            throw RaydExecutionException("Missing operand.")
        }

        return stack.removeLast()
    }

    private fun applyUnaryOperator(code: Int, value: BigDecimal): BigDecimal {
        return when (code) {
            INTERNAL_NEGATE -> value.negate(workContext)
            RaydOpcode.SQUARE -> value.multiply(value, workContext)
            RaydOpcode.CUBE -> value.multiply(value, workContext).multiply(value, workContext)
            RaydOpcode.INVERSE -> {
                if (value.compareTo(zero) == 0) {
                    throw RaydExecutionException("Division by zero.")
                }
                one.divide(value, workContext)
            }
            RaydOpcode.FACTORIAL -> factorial(value)
            RaydOpcode.PERCENT -> value.divide(hundred, workContext)
            else -> throw RaydExecutionException("Unsupported unary operator: 0x${code.toString(16)}")
        }
    }

    private fun applyBinaryOperator(
        code: Int,
        left: BigDecimal,
        right: BigDecimal
    ): BigDecimal {
        return when (code) {
            RaydOpcode.ADD -> left.add(right, workContext)
            RaydOpcode.SUBTRACT -> left.subtract(right, workContext)
            RaydOpcode.MULTIPLY -> left.multiply(right, workContext)

            RaydOpcode.DIVIDE -> {
                if (right.compareTo(zero) == 0) {
                    throw RaydExecutionException("Division by zero.")
                }

                left.divide(right, workContext)
            }

            RaydOpcode.POWER -> power(left, right)
            RaydOpcode.NTH_ROOT -> nthRoot(left, right)
            RaydOpcode.NPR -> permutation(left, right)
            RaydOpcode.NCR -> combination(left, right)

            else -> throw RaydExecutionException("Unsupported binary operator: 0x${code.toString(16)}")
        }
    }

    private fun applyFunction(
        code: Int,
        argument: BigDecimal,
        angleMode: RaydAngleMode
    ): BigDecimal {
        return when (code) {
            RaydOpcode.SQRT_OPEN -> sqrt(argument)
            RaydOpcode.ABS_OPEN -> argument.abs(workContext)
            RaydOpcode.SIN_OPEN -> sin(argument, angleMode)
            RaydOpcode.COS_OPEN -> cos(argument, angleMode)
            RaydOpcode.TAN_OPEN -> tan(argument, angleMode)
            RaydOpcode.LOG_OPEN -> log10(argument)
            RaydOpcode.LN_OPEN -> ln(argument)
            RaydOpcode.CBRT_OPEN -> cubeRoot(argument)
            RaydOpcode.POW10_OPEN -> power(ten, argument)
            RaydOpcode.EXP_OPEN -> exp(argument)
            RaydOpcode.ASIN_OPEN -> fromRadians(asin(argument), angleMode)
            RaydOpcode.ACOS_OPEN -> fromRadians(acos(argument), angleMode)
            RaydOpcode.ATAN_OPEN -> fromRadians(atan(argument), angleMode)
            RaydOpcode.SINH_OPEN -> sinh(argument)
            RaydOpcode.COSH_OPEN -> cosh(argument)
            RaydOpcode.TANH_OPEN -> tanh(argument)
            else -> throw RaydExecutionException("Unsupported function: 0x${code.toString(16)}")
        }
    }

    private fun sin(
        angle: BigDecimal,
        angleMode: RaydAngleMode
    ): BigDecimal {
        val x = normalizeRadians(toRadians(angle, angleMode))
        val xSquared = x.multiply(x, workContext)

        var term = x
        var sum = x

        for (n in 1..40) {
            val denominator = decimal((2 * n) * (2 * n + 1))
            term = term
                .multiply(xSquared, workContext)
                .negate(workContext)
                .divide(denominator, workContext)

            sum = sum.add(term, workContext)

            if (term.abs().compareTo(seriesEpsilon) <= 0) {
                break
            }
        }

        return snapTiny(sum.round(workContext))
    }

    private fun cos(
        angle: BigDecimal,
        angleMode: RaydAngleMode
    ): BigDecimal {
        val x = normalizeRadians(toRadians(angle, angleMode))
        val xSquared = x.multiply(x, workContext)

        var term = one
        var sum = one

        for (n in 1..40) {
            val denominator = decimal((2 * n - 1) * (2 * n))
            term = term
                .multiply(xSquared, workContext)
                .negate(workContext)
                .divide(denominator, workContext)

            sum = sum.add(term, workContext)

            if (term.abs().compareTo(seriesEpsilon) <= 0) {
                break
            }
        }

        return snapTiny(sum.round(workContext))
    }

    private fun tan(
        angle: BigDecimal,
        angleMode: RaydAngleMode
    ): BigDecimal {
        val sinValue = sin(angle, angleMode)
        val cosValue = cos(angle, angleMode)

        if (cosValue.abs().compareTo(tangentZeroEpsilon) <= 0) {
            throw RaydExecutionException("tan is undefined for this angle.")
        }

        return snapTiny(sinValue.divide(cosValue, workContext))
    }

    private fun sqrt(value: BigDecimal): BigDecimal {
        if (value.compareTo(zero) < 0) {
            throw RaydExecutionException("Square root of negative number.")
        }

        if (value.compareTo(zero) == 0) {
            return zero
        }

        var x = if (value.compareTo(one) < 0) one else value.round(workContext)

        for (iteration in 0 until 50) {
            val next = x.add(value.divide(x, workContext), workContext).divide(two, workContext)
            if (x.subtract(next, workContext).abs().compareTo(seriesEpsilon) <= 0) {
                return next.round(workContext)
            }
            x = next
        }

        return x.round(workContext)
    }

    private fun factorial(value: BigDecimal): BigDecimal {
        val n = toNonNegativeIntExact(value, "factorial", max = 500)
        var result = BigDecimal.ONE

        for (i in 2..n) {
            result = result.multiply(decimal(i), workContext)
        }

        return result
    }

    private fun power(base: BigDecimal, exponent: BigDecimal): BigDecimal {
        val integerExponent = exponent.toIntegerExactOrNull()

        if (integerExponent != null) {
            if (integerExponent == 0) return one
            if (base.compareTo(zero) == 0 && integerExponent < 0) {
                throw RaydExecutionException("Zero cannot be raised to a negative power.")
            }

            val absExponent = kotlin.math.abs(integerExponent)
            if (absExponent > 10_000) {
                throw RaydExecutionException("Exponent is too large.")
            }

            var result = one
            repeat(absExponent) {
                result = result.multiply(base, workContext)
            }

            return if (integerExponent < 0) {
                one.divide(result, workContext)
            } else {
                result
            }
        }

        if (base.compareTo(zero) <= 0) {
            throw RaydExecutionException("Decimal powers require a positive base.")
        }

        return exp(ln(base).multiply(exponent, workContext))
    }

    private fun ln(value: BigDecimal): BigDecimal {
        if (value.compareTo(zero) <= 0) {
            throw RaydExecutionException("Logarithm is only defined for positive values.")
        }

        var y = value.round(workContext)
        var decimalExponent = 0

        while (y.compareTo(ten) >= 0) {
            y = y.divide(ten, workContext)
            decimalExponent += 1
        }

        while (y.compareTo(one) < 0) {
            y = y.multiply(ten, workContext)
            decimalExponent -= 1
        }

        var rootCount = 0
        val high = BigDecimal("1.5", workContext)
        val low = BigDecimal("0.75", workContext)

        while ((y.compareTo(high) > 0 || y.compareTo(low) < 0) && rootCount < 24) {
            y = sqrt(y)
            rootCount += 1
        }

        val z = y.subtract(one, workContext).divide(y.add(one, workContext), workContext)
        val zSquared = z.multiply(z, workContext)
        var term = z
        var sum = z

        for (n in 1..120) {
            term = term.multiply(zSquared, workContext)
            val addend = term.divide(decimal(2 * n + 1), workContext)
            sum = sum.add(addend, workContext)

            if (addend.abs().compareTo(seriesEpsilon) <= 0) {
                break
            }
        }

        var result = sum.multiply(two, workContext)

        repeat(rootCount) {
            result = result.multiply(two, workContext)
        }

        if (decimalExponent != 0) {
            result = result.add(lnTen.multiply(decimal(decimalExponent), workContext), workContext)
        }

        return result.round(workContext)
    }

    private fun log10(value: BigDecimal): BigDecimal {
        return ln(value).divide(lnTen, workContext)
    }

    private fun exp(value: BigDecimal): BigDecimal {
        if (value.compareTo(zero) == 0) return one

        var x = value.round(workContext)
        var scaleCount = 0

        while (x.abs().compareTo(BigDecimal("0.5", workContext)) > 0 && scaleCount < 32) {
            x = x.divide(two, workContext)
            scaleCount += 1
        }

        var term = one
        var sum = one

        for (n in 1..120) {
            term = term.multiply(x, workContext).divide(decimal(n), workContext)
            sum = sum.add(term, workContext)

            if (term.abs().compareTo(seriesEpsilon) <= 0) {
                break
            }
        }

        var result = sum
        repeat(scaleCount) {
            result = result.multiply(result, workContext)
        }

        return result.round(workContext)
    }


    private fun cubeRoot(value: BigDecimal): BigDecimal {
        if (value.compareTo(zero) == 0) return zero

        val negative = value.compareTo(zero) < 0
        val target = if (negative) value.negate(workContext) else value
        var x = if (target.compareTo(one) < 0) one else target.round(workContext)

        for (iteration in 0 until 70) {
            val xSquared = x.multiply(x, workContext)
            val next = x.multiply(two, workContext)
                .add(target.divide(xSquared, workContext), workContext)
                .divide(BigDecimal("3", workContext), workContext)

            if (x.subtract(next, workContext).abs().compareTo(seriesEpsilon) <= 0) {
                return if (negative) next.negate(workContext) else next.round(workContext)
            }

            x = next
        }

        return if (negative) x.negate(workContext) else x.round(workContext)
    }

    private fun nthRoot(degreeValue: BigDecimal, radicand: BigDecimal): BigDecimal {
        val degree = toPositiveIntExact(degreeValue, "root degree", max = 99)
        if (degree == 0) {
            throw RaydExecutionException("Root degree cannot be zero.")
        }
        if (degree == 1) return radicand.round(workContext)
        if (degree == 2) return sqrt(radicand)
        if (degree == 3) return cubeRoot(radicand)

        if (radicand.compareTo(zero) < 0) {
            if (degree % 2 == 0) {
                throw RaydExecutionException("Even root of a negative number.")
            }
            return power(radicand.negate(workContext), one.divide(decimal(degree), workContext)).negate(workContext)
        }

        return power(radicand, one.divide(decimal(degree), workContext))
    }

    private fun permutation(nValue: BigDecimal, rValue: BigDecimal): BigDecimal {
        val n = toNonNegativeIntExact(nValue, "nPr n", max = 500)
        val r = toNonNegativeIntExact(rValue, "nPr r", max = 500)

        if (r > n) return zero

        var result = one
        for (i in 0 until r) {
            result = result.multiply(decimal(n - i), workContext)
        }
        return result
    }

    private fun combination(nValue: BigDecimal, rValue: BigDecimal): BigDecimal {
        val n = toNonNegativeIntExact(nValue, "nCr n", max = 500)
        val rRaw = toNonNegativeIntExact(rValue, "nCr r", max = 500)

        if (rRaw > n) return zero

        val r = minOf(rRaw, n - rRaw)
        var numerator = one
        var denominator = one

        for (i in 1..r) {
            numerator = numerator.multiply(decimal(n - r + i), workContext)
            denominator = denominator.multiply(decimal(i), workContext)
        }

        return numerator.divide(denominator, workContext)
    }

    private fun sinh(value: BigDecimal): BigDecimal {
        val positive = exp(value)
        val negative = exp(value.negate(workContext))
        return positive.subtract(negative, workContext).divide(two, workContext)
    }

    private fun cosh(value: BigDecimal): BigDecimal {
        val positive = exp(value)
        val negative = exp(value.negate(workContext))
        return positive.add(negative, workContext).divide(two, workContext)
    }

    private fun tanh(value: BigDecimal): BigDecimal {
        val denominator = cosh(value)
        if (denominator.compareTo(zero) == 0) {
            throw RaydExecutionException("tanh denominator is zero.")
        }
        return sinh(value).divide(denominator, workContext)
    }

    private fun asin(value: BigDecimal): BigDecimal {
        if (value.compareTo(one) > 0 || value.compareTo(one.negate(workContext)) < 0) {
            throw RaydExecutionException("sin⁻¹ input must be between -1 and 1.")
        }

        if (value.compareTo(one) == 0) return pi.divide(two, workContext)
        if (value.compareTo(one.negate(workContext)) == 0) return pi.divide(two, workContext).negate(workContext)

        val denominator = sqrt(one.subtract(value.multiply(value, workContext), workContext))
        return atan(value.divide(denominator, workContext))
    }

    private fun acos(value: BigDecimal): BigDecimal {
        if (value.compareTo(one) > 0 || value.compareTo(one.negate(workContext)) < 0) {
            throw RaydExecutionException("cos⁻¹ input must be between -1 and 1.")
        }

        return pi.divide(two, workContext).subtract(asin(value), workContext)
    }

    private fun atan(value: BigDecimal): BigDecimal {
        val absValue = value.abs()
        val sign = if (value.compareTo(zero) < 0) -1 else 1

        val result = when {
            absValue.compareTo(one) > 0 -> {
                val reciprocal = one.divide(absValue, workContext)
                pi.divide(two, workContext).subtract(atan(reciprocal), workContext)
            }

            absValue.compareTo(BigDecimal("0.5", workContext)) > 0 -> {
                /*
                 * Half-angle reduction:
                 * atan(x) = 2 atan(x / (1 + sqrt(1 + x²))).
                 * This avoids the slow alternating series around x = 1.
                 */
                val denominator = one.add(
                    sqrt(one.add(absValue.multiply(absValue, workContext), workContext)),
                    workContext
                )
                atan(absValue.divide(denominator, workContext)).multiply(two, workContext)
            }

            else -> atanSeries(absValue)
        }

        return if (sign < 0) result.negate(workContext) else result
    }

    private fun atanSeries(value: BigDecimal): BigDecimal {
        val xSquared = value.multiply(value, workContext)
        var term = value
        var sum = value

        for (n in 1..160) {
            term = term.multiply(xSquared, workContext).negate(workContext)
            val addend = term.divide(decimal(2 * n + 1), workContext)
            sum = sum.add(addend, workContext)

            if (addend.abs().compareTo(seriesEpsilon) <= 0) {
                break
            }
        }

        return sum.round(workContext)
    }

    private fun fromRadians(
        radians: BigDecimal,
        angleMode: RaydAngleMode
    ): BigDecimal {
        return when (angleMode) {
            RaydAngleMode.DEGREES ->
                radians.multiply(oneEighty, workContext).divide(pi, workContext)

            RaydAngleMode.RADIANS ->
                radians.round(workContext)

            RaydAngleMode.GRADS ->
                radians.multiply(twoHundred, workContext).divide(pi, workContext)
        }
    }

    private fun randomUnit(): BigDecimal {
        val sample = Random.nextLong(0L, 1_000_000_000L)
        return BigDecimal(sample.toString(), workContext).divide(BigDecimal("1000000000", workContext), workContext)
    }

    private fun toRadians(
        angle: BigDecimal,
        angleMode: RaydAngleMode
    ): BigDecimal {
        return when (angleMode) {
            RaydAngleMode.DEGREES ->
                angle.multiply(pi, workContext).divide(oneEighty, workContext)

            RaydAngleMode.RADIANS ->
                angle.round(workContext)

            RaydAngleMode.GRADS ->
                angle.multiply(pi, workContext).divide(twoHundred, workContext)
        }
    }

    private fun normalizeRadians(radians: BigDecimal): BigDecimal {
        var reduced = radians.remainder(twoPi, workContext)

        if (reduced.compareTo(pi) > 0) {
            reduced = reduced.subtract(twoPi, workContext)
        }

        if (reduced.compareTo(pi.negate(workContext)) < 0) {
            reduced = reduced.add(twoPi, workContext)
        }

        return reduced.round(workContext)
    }

    private fun snapTiny(value: BigDecimal): BigDecimal {
        val rounded = value.round(mathContext)

        if (rounded.abs().compareTo(displayZeroEpsilon) <= 0) {
            return zero
        }

        /*
         * Series based functions intentionally avoid Double/Float. Small residuals
         * still appear around exact calculator values, e.g. tan(45°) can produce
         * 0.999999999999999. Snap values that are within display epsilon of an
         * integer so common scientific results render like a physical calculator.
         */
        val nearestInteger = rounded.setScale(0, RoundingMode.HALF_UP)
        return if (
            rounded.subtract(nearestInteger, mathContext)
                .abs()
                .compareTo(displayZeroEpsilon) <= 0
        ) {
            nearestInteger
        } else {
            rounded
        }
    }

    private fun parseNumber(
        tokens: List<RaydToken>,
        startIndex: Int
    ): ParsedNumber {
        val builder = StringBuilder()
        var index = startIndex
        var hasDecimalPoint = false
        var hasDigit = false

        while (index < tokens.size) {
            val token = tokens[index]

            when (token.kind) {
                RaydTokenKind.DIGIT -> {
                    builder.append(token.display)
                    hasDigit = true
                    index += 1
                }

                RaydTokenKind.DECIMAL_POINT -> {
                    if (hasDecimalPoint) {
                        throw RaydParseException("Number contains multiple decimal points.")
                    }

                    builder.append(".")
                    hasDecimalPoint = true
                    index += 1
                }

                else -> break
            }
        }

        if (!hasDigit) {
            throw RaydParseException("Invalid decimal number.")
        }

        val raw = builder.toString()
        val normalized = when {
            raw.startsWith(".") -> "0$raw"
            raw.endsWith(".") -> "${raw}0"
            else -> raw
        }

        return ParsedNumber(
            value = BigDecimal(normalized, workContext),
            nextIndex = index
        )
    }

    private fun beginsValue(token: RaydToken): Boolean {
        return when (token.kind) {
            RaydTokenKind.DIGIT,
            RaydTokenKind.DECIMAL_POINT,
            RaydTokenKind.ANSWER,
            RaydTokenKind.CONSTANT,
            RaydTokenKind.FUNCTION_OPEN,
            RaydTokenKind.LEFT_PAREN,
            RaydTokenKind.FRACTION_OPEN -> true

            RaydTokenKind.OPERATOR,
            RaydTokenKind.POSTFIX_OPERATOR,
            RaydTokenKind.RIGHT_PAREN,
            RaydTokenKind.FRACTION_DIVIDER,
            RaydTokenKind.FRACTION_CLOSE -> false
        }
    }

    private fun pushOperator(
        incoming: OperatorInfo,
        stack: ArrayDeque<StackEntry>,
        output: MutableList<RaydPostfixToken>
    ) {
        while (!stack.isEmpty()) {
            val top = stack.peekLast()

            if (top !is StackEntry.Operator) {
                break
            }

            val shouldPop = if (incoming.rightAssociative) {
                incoming.precedence < top.info.precedence
            } else {
                incoming.precedence <= top.info.precedence
            }

            if (!shouldPop) {
                break
            }

            output.add(stack.removeLast().asOperator().info.toPostfixOperator())
        }

        stack.addLast(StackEntry.Operator(incoming))
    }

    private fun closeParenthesis(
        stack: ArrayDeque<StackEntry>,
        output: MutableList<RaydPostfixToken>
    ) {
        var foundLeftParenthesis = false

        while (!stack.isEmpty() && !foundLeftParenthesis) {
            when (val entry = stack.removeLast()) {
                StackEntry.LeftParenthesis -> {
                    foundLeftParenthesis = true
                }

                is StackEntry.Operator -> {
                    output.add(entry.info.toPostfixOperator())
                }

                is StackEntry.Function -> {
                    throw RaydParseException("Unexpected function marker '${entry.info.name}'.")
                }
            }
        }

        if (!foundLeftParenthesis) {
            throw RaydParseException("Missing opening parenthesis.")
        }

        val maybeFunction = stack.peekLast()
        if (maybeFunction is StackEntry.Function) {
            output.add(stack.removeLast().asFunction().info.toPostfixFunction())
        }
    }

    private fun binaryOperatorFor(code: Int): OperatorInfo {
        return when (code) {
            RaydOpcode.ADD -> OperatorInfo(
                code = RaydOpcode.ADD,
                symbol = "+",
                precedence = 1,
                rightAssociative = false,
                arity = 2
            )

            RaydOpcode.SUBTRACT -> OperatorInfo(
                code = RaydOpcode.SUBTRACT,
                symbol = "−",
                precedence = 1,
                rightAssociative = false,
                arity = 2
            )

            RaydOpcode.MULTIPLY -> OperatorInfo(
                code = RaydOpcode.MULTIPLY,
                symbol = "×",
                precedence = 2,
                rightAssociative = false,
                arity = 2
            )

            RaydOpcode.DIVIDE -> OperatorInfo(
                code = RaydOpcode.DIVIDE,
                symbol = "÷",
                precedence = 2,
                rightAssociative = false,
                arity = 2
            )

            RaydOpcode.POWER -> OperatorInfo(
                code = RaydOpcode.POWER,
                symbol = "^",
                precedence = 4,
                rightAssociative = true,
                arity = 2
            )

            RaydOpcode.NTH_ROOT -> OperatorInfo(
                code = RaydOpcode.NTH_ROOT,
                symbol = "√",
                precedence = 4,
                rightAssociative = true,
                arity = 2
            )

            RaydOpcode.NPR -> OperatorInfo(
                code = RaydOpcode.NPR,
                symbol = "P",
                precedence = 2,
                rightAssociative = false,
                arity = 2
            )

            RaydOpcode.NCR -> OperatorInfo(
                code = RaydOpcode.NCR,
                symbol = "C",
                precedence = 2,
                rightAssociative = false,
                arity = 2
            )

            else -> throw RaydParseException("Unknown operator opcode: 0x${code.toString(16)}")
        }
    }

    private fun postfixOperatorFor(code: Int): OperatorInfo {
        return when (code) {
            RaydOpcode.SQUARE -> OperatorInfo(
                code = RaydOpcode.SQUARE,
                symbol = "²",
                precedence = 5,
                rightAssociative = false,
                arity = 1
            )

            RaydOpcode.INVERSE -> OperatorInfo(
                code = RaydOpcode.INVERSE,
                symbol = "⁻¹",
                precedence = 5,
                rightAssociative = false,
                arity = 1
            )

            RaydOpcode.FACTORIAL -> OperatorInfo(
                code = RaydOpcode.FACTORIAL,
                symbol = "!",
                precedence = 5,
                rightAssociative = false,
                arity = 1
            )

            RaydOpcode.PERCENT -> OperatorInfo(
                code = RaydOpcode.PERCENT,
                symbol = "%",
                precedence = 5,
                rightAssociative = false,
                arity = 1
            )

            RaydOpcode.CUBE -> OperatorInfo(
                code = RaydOpcode.CUBE,
                symbol = "³",
                precedence = 5,
                rightAssociative = false,
                arity = 1
            )

            else -> throw RaydParseException("Unknown postfix opcode: 0x${code.toString(16)}")
        }
    }

    private fun unaryMinusOperator(): OperatorInfo =
        OperatorInfo(
            code = INTERNAL_NEGATE,
            symbol = "neg",
            precedence = 3,
            rightAssociative = true,
            arity = 1
        )

    private fun functionFor(code: Int): FunctionInfo {
        return when (code) {
            RaydOpcode.SQRT_OPEN -> FunctionInfo(code, "sqrt")
            RaydOpcode.ABS_OPEN -> FunctionInfo(code, "abs")
            RaydOpcode.SIN_OPEN -> FunctionInfo(code, "sin")
            RaydOpcode.COS_OPEN -> FunctionInfo(code, "cos")
            RaydOpcode.TAN_OPEN -> FunctionInfo(code, "tan")
            RaydOpcode.LOG_OPEN -> FunctionInfo(code, "log")
            RaydOpcode.LN_OPEN -> FunctionInfo(code, "ln")
            RaydOpcode.CBRT_OPEN -> FunctionInfo(code, "cbrt")
            RaydOpcode.POW10_OPEN -> FunctionInfo(code, "pow10")
            RaydOpcode.EXP_OPEN -> FunctionInfo(code, "exp")
            RaydOpcode.ASIN_OPEN -> FunctionInfo(code, "asin")
            RaydOpcode.ACOS_OPEN -> FunctionInfo(code, "acos")
            RaydOpcode.ATAN_OPEN -> FunctionInfo(code, "atan")
            RaydOpcode.SINH_OPEN -> FunctionInfo(code, "sinh")
            RaydOpcode.COSH_OPEN -> FunctionInfo(code, "cosh")
            RaydOpcode.TANH_OPEN -> FunctionInfo(code, "tanh")
            else -> throw RaydParseException("Unknown function opcode: 0x${code.toString(16)}")
        }
    }

    private fun OperatorInfo.toPostfixOperator(): RaydPostfixToken.Operator =
        RaydPostfixToken.Operator(
            code = code,
            symbol = symbol,
            arity = arity
        )

    private fun FunctionInfo.toPostfixFunction(): RaydPostfixToken.Function =
        RaydPostfixToken.Function(
            code = code,
            name = name
        )

    private fun StackEntry.asOperator(): StackEntry.Operator =
        this as? StackEntry.Operator
            ?: throw RaydParseException("Expected operator on parser stack.")

    private fun StackEntry.asFunction(): StackEntry.Function =
        this as? StackEntry.Function
            ?: throw RaydParseException("Expected function on parser stack.")

    private fun decimal(value: Int): BigDecimal =
        BigDecimal(value.toString(), workContext)

    private fun BigDecimal.toIntegerExactOrNull(): Int? {
        return try {
            this.stripTrailingZeros().toBigIntegerExact().intValueExact()
        } catch (exception: ArithmeticException) {
            null
        }
    }

    private fun toPositiveIntExact(
        value: BigDecimal,
        label: String,
        max: Int
    ): Int {
        val integer = toNonNegativeIntExact(value, label, max)
        if (integer <= 0) {
            throw RaydExecutionException("$label requires a positive integer.")
        }
        return integer
    }

    private fun toNonNegativeIntExact(
        value: BigDecimal,
        label: String,
        max: Int
    ): Int {
        val integer = try {
            value.stripTrailingZeros().toBigIntegerExact()
        } catch (exception: ArithmeticException) {
            throw RaydExecutionException("$label requires an integer.")
        }

        if (integer < BigInteger.ZERO) {
            throw RaydExecutionException("$label requires a non-negative integer.")
        }

        if (integer > BigInteger.valueOf(max.toLong())) {
            throw RaydExecutionException("$label is limited to $max for mobile execution.")
        }

        return integer.intValueExact()
    }

    private data class ParsedNumber(
        val value: BigDecimal,
        val nextIndex: Int
    )

    private data class OperatorInfo(
        val code: Int,
        val symbol: String,
        val precedence: Int,
        val rightAssociative: Boolean,
        val arity: Int
    )

    private data class FunctionInfo(
        val code: Int,
        val name: String
    )

    private sealed class StackEntry {
        data class Operator(val info: OperatorInfo) : StackEntry()
        data class Function(val info: FunctionInfo) : StackEntry()
        data object LeftParenthesis : StackEntry()
    }

    private class RaydParseException(message: String) : RuntimeException(message)
    private class RaydExecutionException(message: String) : RuntimeException(message)

    companion object {
        private const val INTERNAL_NEGATE: Int = 0x0E
    }
}
