package com.rayd.calculator

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList

object RaydOpcode {
    const val ADD: Int = 0x01
    const val SUBTRACT: Int = 0x02
    const val MULTIPLY: Int = 0x03
    const val DIVIDE: Int = 0x04
    const val POWER: Int = 0x05

    const val SQUARE: Int = 0x06
    const val INVERSE: Int = 0x07
    const val FACTORIAL: Int = 0x08
    const val PERCENT: Int = 0x09
    const val CUBE: Int = 0x0A
    const val NPR: Int = 0x0B
    const val NCR: Int = 0x0C
    const val NTH_ROOT: Int = 0x0D

    const val SQRT_OPEN: Int = 0x18
    const val ABS_OPEN: Int = 0x19
    const val SIN_OPEN: Int = 0x1A
    const val COS_OPEN: Int = 0x1B
    const val TAN_OPEN: Int = 0x1C
    const val LOG_OPEN: Int = 0x1D
    const val LN_OPEN: Int = 0x1E
    const val CBRT_OPEN: Int = 0x1F
    const val POW10_OPEN: Int = 0x20
    const val EXP_OPEN: Int = 0x21
    const val ASIN_OPEN: Int = 0x22
    const val ACOS_OPEN: Int = 0x23
    const val ATAN_OPEN: Int = 0x24
    const val SINH_OPEN: Int = 0x25
    const val COSH_OPEN: Int = 0x26
    const val TANH_OPEN: Int = 0x27

    const val LEFT_PAREN: Int = 0x28
    const val RIGHT_PAREN: Int = 0x29
    const val DECIMAL_POINT: Int = 0x2E

    const val DIGIT_ZERO: Int = 0x30
    const val DIGIT_NINE: Int = 0x39

    const val FRACTION_OPEN: Int = 0x3A
    const val FRACTION_DIVIDER: Int = 0x3B
    const val FRACTION_CLOSE: Int = 0x3C

    const val ANSWER: Int = 0x41
    const val CONST_PI: Int = 0x42
    const val CONST_E: Int = 0x43
    const val CONST_RANDOM: Int = 0x44
}

enum class RaydTokenKind {
    DIGIT,
    DECIMAL_POINT,
    OPERATOR,
    POSTFIX_OPERATOR,
    FUNCTION_OPEN,
    CONSTANT,
    LEFT_PAREN,
    RIGHT_PAREN,
    FRACTION_OPEN,
    FRACTION_DIVIDER,
    FRACTION_CLOSE,
    ANSWER
}

data class RaydToken(
    val code: Int,
    val kind: RaydTokenKind,
    val display: String,
    val solidBlock: Boolean = false
) {
    init {
        require(code in 0x00..0xFF) {
            "Token code must fit inside an unsigned byte: $code"
        }
    }

    val byteCode: Byte
        get() = code.toByte()

    companion object {
        fun digit(digit: Int): RaydToken {
            require(digit in 0..9) { "Digit must be in range 0..9." }
            return RaydToken(
                code = RaydOpcode.DIGIT_ZERO + digit,
                kind = RaydTokenKind.DIGIT,
                display = digit.toString(),
                solidBlock = true
            )
        }

        fun decimalPoint(): RaydToken =
            RaydToken(
                code = RaydOpcode.DECIMAL_POINT,
                kind = RaydTokenKind.DECIMAL_POINT,
                display = ".",
                solidBlock = true
            )

        fun operator(code: Int): RaydToken {
            val symbol = when (code) {
                RaydOpcode.ADD -> "+"
                RaydOpcode.SUBTRACT -> "−"
                RaydOpcode.MULTIPLY -> "×"
                RaydOpcode.DIVIDE -> "÷"
                RaydOpcode.POWER -> "^"
                RaydOpcode.NTH_ROOT -> "√"
                RaydOpcode.NPR -> "P"
                RaydOpcode.NCR -> "C"
                else -> error("Unsupported operator opcode: 0x${code.toString(16)}")
            }

            return RaydToken(
                code = code,
                kind = RaydTokenKind.OPERATOR,
                display = symbol,
                solidBlock = true
            )
        }

        fun postfixOperator(code: Int): RaydToken {
            val symbol = when (code) {
                RaydOpcode.SQUARE -> "²"
                RaydOpcode.INVERSE -> "⁻¹"
                RaydOpcode.FACTORIAL -> "!"
                RaydOpcode.PERCENT -> "%"
                RaydOpcode.CUBE -> "³"
                else -> error("Unsupported postfix opcode: 0x${code.toString(16)}")
            }

            return RaydToken(
                code = code,
                kind = RaydTokenKind.POSTFIX_OPERATOR,
                display = symbol,
                solidBlock = true
            )
        }

        fun functionOpen(code: Int): RaydToken {
            val symbol = when (code) {
                RaydOpcode.SQRT_OPEN -> "√("
                RaydOpcode.ABS_OPEN -> "abs("
                RaydOpcode.SIN_OPEN -> "sin("
                RaydOpcode.COS_OPEN -> "cos("
                RaydOpcode.TAN_OPEN -> "tan("
                RaydOpcode.LOG_OPEN -> "log("
                RaydOpcode.LN_OPEN -> "ln("
                RaydOpcode.CBRT_OPEN -> "∛("
                RaydOpcode.POW10_OPEN -> "10^("
                RaydOpcode.EXP_OPEN -> "e^("
                RaydOpcode.ASIN_OPEN -> "sin⁻¹("
                RaydOpcode.ACOS_OPEN -> "cos⁻¹("
                RaydOpcode.ATAN_OPEN -> "tan⁻¹("
                RaydOpcode.SINH_OPEN -> "sinh("
                RaydOpcode.COSH_OPEN -> "cosh("
                RaydOpcode.TANH_OPEN -> "tanh("
                else -> error("Unsupported function opcode: 0x${code.toString(16)}")
            }

            return RaydToken(
                code = code,
                kind = RaydTokenKind.FUNCTION_OPEN,
                display = symbol,
                solidBlock = true
            )
        }

        fun constant(code: Int): RaydToken {
            val symbol = when (code) {
                RaydOpcode.CONST_PI -> "π"
                RaydOpcode.CONST_E -> "e"
                RaydOpcode.CONST_RANDOM -> "Ran#"
                else -> error("Unsupported constant opcode: 0x${code.toString(16)}")
            }

            return RaydToken(
                code = code,
                kind = RaydTokenKind.CONSTANT,
                display = symbol,
                solidBlock = true
            )
        }

        fun leftParen(): RaydToken =
            RaydToken(
                code = RaydOpcode.LEFT_PAREN,
                kind = RaydTokenKind.LEFT_PAREN,
                display = "(",
                solidBlock = true
            )

        fun rightParen(): RaydToken =
            RaydToken(
                code = RaydOpcode.RIGHT_PAREN,
                kind = RaydTokenKind.RIGHT_PAREN,
                display = ")",
                solidBlock = true
            )

        fun fractionOpen(): RaydToken =
            RaydToken(
                code = RaydOpcode.FRACTION_OPEN,
                kind = RaydTokenKind.FRACTION_OPEN,
                display = "⟦",
                solidBlock = true
            )

        fun fractionDivider(): RaydToken =
            RaydToken(
                code = RaydOpcode.FRACTION_DIVIDER,
                kind = RaydTokenKind.FRACTION_DIVIDER,
                display = "∕",
                solidBlock = true
            )

        fun fractionClose(): RaydToken =
            RaydToken(
                code = RaydOpcode.FRACTION_CLOSE,
                kind = RaydTokenKind.FRACTION_CLOSE,
                display = "⟧",
                solidBlock = true
            )

        fun answer(): RaydToken =
            RaydToken(
                code = RaydOpcode.ANSWER,
                kind = RaydTokenKind.ANSWER,
                display = "Ans",
                solidBlock = true
            )

        fun fromCode(code: Int): RaydToken {
            require(code in 0x00..0xFF) {
                "Token code must fit inside an unsigned byte: $code"
            }

            return when {
                code in RaydOpcode.DIGIT_ZERO..RaydOpcode.DIGIT_NINE ->
                    digit(code - RaydOpcode.DIGIT_ZERO)

                code == RaydOpcode.DECIMAL_POINT -> decimalPoint()

                code == RaydOpcode.ADD ||
                    code == RaydOpcode.SUBTRACT ||
                    code == RaydOpcode.MULTIPLY ||
                    code == RaydOpcode.DIVIDE ||
                    code == RaydOpcode.POWER ||
                    code == RaydOpcode.NTH_ROOT ||
                    code == RaydOpcode.NPR ||
                    code == RaydOpcode.NCR -> operator(code)

                code == RaydOpcode.SQUARE ||
                    code == RaydOpcode.INVERSE ||
                    code == RaydOpcode.FACTORIAL ||
                    code == RaydOpcode.PERCENT ||
                    code == RaydOpcode.CUBE -> postfixOperator(code)

                code == RaydOpcode.SQRT_OPEN ||
                    code == RaydOpcode.ABS_OPEN ||
                    code == RaydOpcode.SIN_OPEN ||
                    code == RaydOpcode.COS_OPEN ||
                    code == RaydOpcode.TAN_OPEN ||
                    code == RaydOpcode.LOG_OPEN ||
                    code == RaydOpcode.LN_OPEN ||
                    code == RaydOpcode.CBRT_OPEN ||
                    code == RaydOpcode.POW10_OPEN ||
                    code == RaydOpcode.EXP_OPEN ||
                    code == RaydOpcode.ASIN_OPEN ||
                    code == RaydOpcode.ACOS_OPEN ||
                    code == RaydOpcode.ATAN_OPEN ||
                    code == RaydOpcode.SINH_OPEN ||
                    code == RaydOpcode.COSH_OPEN ||
                    code == RaydOpcode.TANH_OPEN -> functionOpen(code)

                code == RaydOpcode.CONST_PI ||
                    code == RaydOpcode.CONST_E ||
                    code == RaydOpcode.CONST_RANDOM -> constant(code)

                code == RaydOpcode.LEFT_PAREN -> leftParen()
                code == RaydOpcode.RIGHT_PAREN -> rightParen()

                code == RaydOpcode.FRACTION_OPEN -> fractionOpen()
                code == RaydOpcode.FRACTION_DIVIDER -> fractionDivider()
                code == RaydOpcode.FRACTION_CLOSE -> fractionClose()

                code == RaydOpcode.ANSWER -> answer()

                else -> error("Unknown Rayd token opcode: 0x${code.toString(16)}")
            }
        }
    }
}

class RaydBuffer(initialTokens: List<RaydToken> = emptyList()) {
    private val _tokens: SnapshotStateList<RaydToken> =
        mutableStateListOf<RaydToken>().apply { addAll(initialTokens) }

    val tokens: List<RaydToken>
        get() = _tokens

    var cursorIndex: Int by mutableIntStateOf(initialTokens.size)
        private set

    val size: Int
        get() = _tokens.size

    fun snapshot(): List<RaydToken> = _tokens.toList()

    fun byteCodeSnapshot(): ByteArray =
        ByteArray(_tokens.size) { index -> _tokens[index].byteCode }

    fun unsignedCodeSnapshot(): IntArray =
        IntArray(_tokens.size) { index -> _tokens[index].code }

    fun insert(token: RaydToken): Boolean {
        _tokens.add(cursorIndex, token)
        cursorIndex += 1
        return true
    }

    fun insertCode(code: Int): Boolean =
        insert(RaydToken.fromCode(code))

    fun insertDigit(digit: Int): Boolean =
        insert(RaydToken.digit(digit))

    fun insertDecimalPoint(): Boolean =
        insert(RaydToken.decimalPoint())

    fun insertOperator(code: Int): Boolean =
        insert(RaydToken.operator(code))

    fun insertPostfixOperator(code: Int): Boolean =
        insert(RaydToken.postfixOperator(code))

    fun insertFunctionOpen(code: Int): Boolean =
        insert(RaydToken.functionOpen(code))

    fun insertConstant(code: Int): Boolean =
        insert(RaydToken.constant(code))

    fun insertLeftParen(): Boolean =
        insert(RaydToken.leftParen())

    fun insertRightParen(): Boolean =
        insert(RaydToken.rightParen())

    fun insertAnswer(): Boolean =
        insert(RaydToken.answer())

    fun insertNumberLiteral(rawValue: String): Boolean {
        val normalized = rawValue.trim()
            .replace("−", "-")
            .removeSuffix(".0")

        if (normalized.isEmpty()) return false

        var inserted = false
        for (char in normalized) {
            when (char) {
                '-' -> inserted = insertOperator(RaydOpcode.SUBTRACT) || inserted
                '+' -> Unit
                '.' -> inserted = insertDecimalPoint() || inserted
                in '0'..'9' -> inserted = insertDigit(char.digitToInt()) || inserted
                else -> return false
            }
        }

        return inserted
    }

    fun insertFractionTemplate(): Boolean {
        val start = cursorIndex
        _tokens.add(start, RaydToken.fractionOpen())
        _tokens.add(start + 1, RaydToken.fractionDivider())
        _tokens.add(start + 2, RaydToken.fractionClose())

        cursorIndex = start + 1
        return true
    }

    fun moveLeft(): Boolean {
        if (cursorIndex == 0) return false
        cursorIndex -= 1
        return true
    }

    fun moveRight(): Boolean {
        if (cursorIndex >= _tokens.size) return false
        cursorIndex += 1
        return true
    }

    fun moveToStart() {
        cursorIndex = 0
    }

    fun moveToEnd() {
        cursorIndex = _tokens.size
    }

    fun deleteBeforeCursor(): Boolean {
        if (cursorIndex == 0) return false

        _tokens.removeAt(cursorIndex - 1)
        cursorIndex -= 1
        return true
    }

    fun deleteAtCursor(): Boolean {
        if (cursorIndex >= _tokens.size) return false

        _tokens.removeAt(cursorIndex)
        return true
    }

    fun clear() {
        _tokens.clear()
        cursorIndex = 0
    }

    fun renderExpression(): String =
        _tokens.joinToString(separator = "") { token -> token.display }

    fun renderExpressionWithCursor(cursorGlyph: String = "│"): String {
        val builder = StringBuilder()

        for (index in 0.._tokens.size) {
            if (index == cursorIndex) {
                builder.append(cursorGlyph)
            }

            if (index < _tokens.size) {
                builder.append(_tokens[index].display)
            }
        }

        return builder.toString()
    }

    fun maxFractionDepth(): Int {
        var depth = 0
        var maxDepth = 0

        for (token in _tokens) {
            when (token.kind) {
                RaydTokenKind.FRACTION_OPEN -> {
                    depth += 1
                    if (depth > maxDepth) maxDepth = depth
                }

                RaydTokenKind.FRACTION_CLOSE -> {
                    depth = (depth - 1).coerceAtLeast(0)
                }

                else -> Unit
            }
        }

        return maxDepth
    }

    fun fractionDepthAtCursor(): Int {
        var depth = 0

        for (index in 0 until cursorIndex.coerceAtMost(_tokens.size)) {
            when (_tokens[index].kind) {
                RaydTokenKind.FRACTION_OPEN -> depth += 1
                RaydTokenKind.FRACTION_CLOSE -> depth = (depth - 1).coerceAtLeast(0)
                else -> Unit
            }
        }

        return depth
    }
}
