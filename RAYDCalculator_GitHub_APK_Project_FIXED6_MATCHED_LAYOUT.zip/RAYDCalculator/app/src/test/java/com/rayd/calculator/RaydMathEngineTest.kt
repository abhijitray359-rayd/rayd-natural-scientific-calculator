package com.rayd.calculator

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RaydMathEngineTest {
    private val engine = RaydMathEngine()

    @Test
    fun shuntingYardHonorsMultiplicationPrecedence() {
        val tokens = listOf(
            RaydToken.digit(2),
            RaydToken.operator(RaydOpcode.ADD),
            RaydToken.digit(3),
            RaydToken.operator(RaydOpcode.MULTIPLY),
            RaydToken.digit(4)
        )

        val result = engine.evaluate(tokens)

        assertTrue(result is RaydEvaluationResult.Success)
        assertEquals("14", (result as RaydEvaluationResult.Success).display)
    }

    @Test
    fun sinNinetyDegreesEvaluatesToOne() {
        val tokens = listOf(
            RaydToken.functionOpen(RaydOpcode.SIN_OPEN),
            RaydToken.digit(9),
            RaydToken.digit(0),
            RaydToken.rightParen()
        )

        val result = engine.evaluate(tokens, angleMode = RaydAngleMode.DEGREES)

        assertTrue(result is RaydEvaluationResult.Success)
        assertEquals("1", (result as RaydEvaluationResult.Success).display)
    }

    @Test
    fun fractionTemplateTokensEvaluateAsDivision() {
        val tokens = listOf(
            RaydToken.fractionOpen(),
            RaydToken.digit(1),
            RaydToken.fractionDivider(),
            RaydToken.digit(2),
            RaydToken.fractionClose()
        )

        val result = engine.evaluate(tokens)

        assertTrue(result is RaydEvaluationResult.Success)
        assertEquals("0.5", (result as RaydEvaluationResult.Success).display)
    }

    @Test
    fun squareRootEvaluates() {
        val tokens = listOf(
            RaydToken.functionOpen(RaydOpcode.SQRT_OPEN),
            RaydToken.digit(9),
            RaydToken.rightParen()
        )

        val result = engine.evaluate(tokens)

        assertTrue(result is RaydEvaluationResult.Success)
        assertEquals("3", (result as RaydEvaluationResult.Success).display)
    }

    @Test
    fun powerEvaluatesRightAssociative() {
        val tokens = listOf(
            RaydToken.digit(2),
            RaydToken.operator(RaydOpcode.POWER),
            RaydToken.digit(3),
            RaydToken.operator(RaydOpcode.POWER),
            RaydToken.digit(2)
        )

        val result = engine.evaluate(tokens)

        assertTrue(result is RaydEvaluationResult.Success)
        assertEquals("512", (result as RaydEvaluationResult.Success).display)
    }

    @Test
    fun factorialEvaluates() {
        val tokens = listOf(
            RaydToken.digit(5),
            RaydToken.postfixOperator(RaydOpcode.FACTORIAL)
        )

        val result = engine.evaluate(tokens)

        assertTrue(result is RaydEvaluationResult.Success)
        assertEquals("120", (result as RaydEvaluationResult.Success).display)
    }

    @Test
    fun logHundredEvaluatesToTwo() {
        val tokens = listOf(
            RaydToken.functionOpen(RaydOpcode.LOG_OPEN),
            RaydToken.digit(1),
            RaydToken.digit(0),
            RaydToken.digit(0),
            RaydToken.rightParen()
        )

        val result = engine.evaluate(tokens)

        assertTrue(result is RaydEvaluationResult.Success)
        assertEquals("2", (result as RaydEvaluationResult.Success).display)
    }


    @Test
    fun tanFortyFiveDegreesSnapsToOne() {
        val tokens = listOf(
            RaydToken.functionOpen(RaydOpcode.TAN_OPEN),
            RaydToken.digit(4),
            RaydToken.digit(5),
            RaydToken.rightParen()
        )

        val result = engine.evaluate(tokens, angleMode = RaydAngleMode.DEGREES)

        assertTrue(result is RaydEvaluationResult.Success)
        assertEquals("1", (result as RaydEvaluationResult.Success).display)
    }

    @Test
    fun inverseEvaluates() {
        val tokens = listOf(
            RaydToken.digit(4),
            RaydToken.postfixOperator(RaydOpcode.INVERSE)
        )

        val result = engine.evaluate(tokens)

        assertTrue(result is RaydEvaluationResult.Success)
        assertEquals("0.25", (result as RaydEvaluationResult.Success).display)
    }

    @Test
    fun constantsAndImplicitMultiplicationEvaluate() {
        val tokens = listOf(
            RaydToken.digit(2),
            RaydToken.constant(RaydOpcode.CONST_PI)
        )

        val result = engine.evaluate(tokens)

        assertTrue(result is RaydEvaluationResult.Success)
        assertEquals("6.28318530717958", (result as RaydEvaluationResult.Success).display)
    }

    @Test
    fun percentEvaluatesAsUnaryDivideByHundred() {
        val tokens = listOf(
            RaydToken.digit(5),
            RaydToken.digit(0),
            RaydToken.postfixOperator(RaydOpcode.PERCENT)
        )

        val result = engine.evaluate(tokens)

        assertTrue(result is RaydEvaluationResult.Success)
        assertEquals("0.5", (result as RaydEvaluationResult.Success).display)
    }

    @Test
    fun naturalLogOfEApproximationEvaluatesToOne() {
        val tokens = listOf(
            RaydToken.functionOpen(RaydOpcode.LN_OPEN),
            RaydToken.constant(RaydOpcode.CONST_E),
            RaydToken.rightParen()
        )

        val result = engine.evaluate(tokens)

        assertTrue(result is RaydEvaluationResult.Success)
        assertEquals("1", (result as RaydEvaluationResult.Success).display)
    }

    @Test
    fun bufferCursorMovesAcrossFunctionAsSingleToken() {
        val buffer = RaydBuffer()

        buffer.insertFunctionOpen(RaydOpcode.SIN_OPEN)

        assertEquals(1, buffer.cursorIndex)
        assertEquals("sin(", buffer.renderExpression())

        buffer.moveLeft()

        assertEquals(0, buffer.cursorIndex)
    }
    @Test
    fun cubeAndCubeRootEvaluate() {
        val cubeTokens = listOf(
            RaydToken.digit(3),
            RaydToken.postfixOperator(RaydOpcode.CUBE)
        )
        val cubeResult = engine.evaluate(cubeTokens)

        assertTrue(cubeResult is RaydEvaluationResult.Success)
        assertEquals("27", (cubeResult as RaydEvaluationResult.Success).display)

        val rootTokens = listOf(
            RaydToken.functionOpen(RaydOpcode.CBRT_OPEN),
            RaydToken.digit(2),
            RaydToken.digit(7),
            RaydToken.rightParen()
        )
        val rootResult = engine.evaluate(rootTokens)

        assertTrue(rootResult is RaydEvaluationResult.Success)
        assertEquals("3", (rootResult as RaydEvaluationResult.Success).display)
    }

    @Test
    fun permutationAndCombinationEvaluate() {
        val permutationTokens = listOf(
            RaydToken.digit(5),
            RaydToken.operator(RaydOpcode.NPR),
            RaydToken.digit(2)
        )
        val permutationResult = engine.evaluate(permutationTokens)

        assertTrue(permutationResult is RaydEvaluationResult.Success)
        assertEquals("20", (permutationResult as RaydEvaluationResult.Success).display)

        val combinationTokens = listOf(
            RaydToken.digit(5),
            RaydToken.operator(RaydOpcode.NCR),
            RaydToken.digit(2)
        )
        val combinationResult = engine.evaluate(combinationTokens)

        assertTrue(combinationResult is RaydEvaluationResult.Success)
        assertEquals("10", (combinationResult as RaydEvaluationResult.Success).display)
    }

    @Test
    fun powersAndInverseTrigEvaluate() {
        val pow10Tokens = listOf(
            RaydToken.functionOpen(RaydOpcode.POW10_OPEN),
            RaydToken.digit(3),
            RaydToken.rightParen()
        )
        val pow10Result = engine.evaluate(pow10Tokens)

        assertTrue(pow10Result is RaydEvaluationResult.Success)
        assertEquals("1000", (pow10Result as RaydEvaluationResult.Success).display)

        val atanTokens = listOf(
            RaydToken.functionOpen(RaydOpcode.ATAN_OPEN),
            RaydToken.digit(1),
            RaydToken.rightParen()
        )
        val atanResult = engine.evaluate(atanTokens, angleMode = RaydAngleMode.DEGREES)

        assertTrue(atanResult is RaydEvaluationResult.Success)
        assertEquals("45", (atanResult as RaydEvaluationResult.Success).display)
    }

    @Test
    fun nthRootEvaluates() {
        val tokens = listOf(
            RaydToken.digit(3),
            RaydToken.operator(RaydOpcode.NTH_ROOT),
            RaydToken.digit(2),
            RaydToken.digit(7)
        )

        val result = engine.evaluate(tokens)

        assertTrue(result is RaydEvaluationResult.Success)
        assertEquals("3", (result as RaydEvaluationResult.Success).display)
    }

}
